from __future__ import annotations

import json
import uuid
from pathlib import Path
from typing import Any

from .common import atomic_write_bytes, sha256_bytes
from .signing import EVENT_TYP, JWSCodec, SigningKey


class SignedEventLog:
    def __init__(
        self,
        *,
        attempt_id: str,
        domain: str,
        signer: SigningKey,
        audience: str,
        authorization_file_sha256: str,
        now: int,
    ) -> None:
        self.attempt_id = attempt_id
        self.domain = domain
        self.signer = signer
        self.audience = audience
        self.authorization_file_sha256 = authorization_file_sha256
        self.now = now
        self.tokens: list[str] = []

    def append(self, kind: str, data: dict[str, Any] | None = None) -> str:
        previous = JWSCodec.digest(self.tokens[-1]) if self.tokens else None
        sequence = len(self.tokens) + 1
        payload = {
            "object_id": f"urn:ctde:event:{uuid.uuid4()}",
            "event_id": f"EVT-{uuid.uuid4()}",
            "environment": "prototype_fixture_only",
            "attempt_id": self.attempt_id,
            "authorization_file_sha256": self.authorization_file_sha256,
            "iss": self.signer.issuer,
            "aud": self.audience,
            "iat": self.now,
            "nbf": self.now,
            "exp": self.now + 300,
            "domain": self.domain,
            "sequence": sequence,
            "previous_event_sha256": previous,
            "kind": kind,
            "data": data or {},
        }
        token = JWSCodec.sign(self.signer, EVENT_TYP, payload)
        self.tokens.append(token)
        return token

    def persist(self, path: Path) -> None:
        rows = [json.dumps({"event_jws": token}, sort_keys=True) for token in self.tokens]
        atomic_write_bytes(path, ("\n".join(rows) + "\n").encode("utf-8"))

    @staticmethod
    def verify(
        tokens: list[str],
        *,
        codec: JWSCodec,
        expected_attempt_id: str,
        expected_domain: str,
        expected_issuer: str,
        expected_audience: str,
    ) -> list[dict[str, Any]]:
        verified: list[dict[str, Any]] = []
        previous: str | None = None
        for index, token in enumerate(tokens, 1):
            _, payload = codec.verify(
                token,
                expected_typ=EVENT_TYP,
                expected_issuer=expected_issuer,
                expected_audience=expected_audience,
                max_ttl=300,
                expected_attempt_id=expected_attempt_id,
            )
            if payload.get("domain") != expected_domain:
                raise ValueError("domain mismatch")
            if payload.get("sequence") != index:
                raise ValueError("sequence mismatch")
            if payload.get("previous_event_sha256") != previous:
                raise ValueError("event chain mismatch")
            previous = sha256_bytes(token.encode("ascii"))
            verified.append(payload)
        if not verified:
            raise ValueError("empty evidence log")
        return verified

