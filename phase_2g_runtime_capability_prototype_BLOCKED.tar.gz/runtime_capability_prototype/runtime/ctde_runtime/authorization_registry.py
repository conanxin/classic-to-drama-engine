from __future__ import annotations

import hashlib
import secrets
import sqlite3
import threading
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .common import PrototypeError, canonical_json_bytes, require, sha256_bytes
from .events import SignedEventLog


@dataclass(frozen=True)
class MintLease:
    authorization_id: str
    attempt_id: str
    consumption_event_id: str
    authorization_digest: str
    secret: bytes


class AuthorizationRegistry:
    def __init__(self, db_path: Path) -> None:
        self.db_path = db_path
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.db_path, timeout=30, isolation_level=None)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA synchronous=FULL")
        return connection

    def _initialize(self) -> None:
        with self._connect() as connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS authorizations (
                    authorization_id TEXT PRIMARY KEY,
                    attempt_id TEXT NOT NULL UNIQUE,
                    authorization_digest TEXT NOT NULL UNIQUE,
                    fixture_object_id TEXT NOT NULL,
                    expires_at INTEGER NOT NULL,
                    immutable_bytes_sha256 TEXT NOT NULL,
                    state TEXT NOT NULL CHECK(state IN ('unconsumed','spent','revoked','expired')),
                    consumption_event_id TEXT,
                    lease_hash TEXT,
                    mint_claimed INTEGER NOT NULL DEFAULT 0,
                    closed INTEGER NOT NULL DEFAULT 0
                );
                CREATE TABLE IF NOT EXISTS registry_events (
                    event_id TEXT PRIMARY KEY,
                    authorization_id TEXT NOT NULL,
                    attempt_id TEXT NOT NULL,
                    kind TEXT NOT NULL,
                    created_at INTEGER NOT NULL
                );
                CREATE TABLE IF NOT EXISTS capabilities (
                    capability_id TEXT PRIMARY KEY,
                    consumption_event_id TEXT NOT NULL UNIQUE,
                    attempt_id TEXT NOT NULL,
                    consumed INTEGER NOT NULL DEFAULT 0
                );
                CREATE TABLE IF NOT EXISTS deliveries (
                    delivery_id TEXT PRIMARY KEY,
                    attempt_id TEXT NOT NULL,
                    consumed INTEGER NOT NULL DEFAULT 0
                );
                """
            )

    def register(self, authorization: dict[str, Any], immutable_bytes: bytes) -> str:
        authorization_id = authorization["authorization_id"]
        digest = sha256_bytes(immutable_bytes)
        require(
            digest == authorization["authorization_file_sha256"],
            "BLOCKED_TEST_AUTHORIZATION_INVALID",
            "authorization digest",
        )
        with self._connect() as connection:
            connection.execute(
                """INSERT INTO authorizations
                   (authorization_id, attempt_id, authorization_digest, fixture_object_id,
                    expires_at, immutable_bytes_sha256, state)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (
                    authorization_id,
                    authorization["attempt_id"],
                    digest,
                    authorization["fixture_object_id"],
                    authorization["expires_at"],
                    digest,
                    "expired" if authorization.get("initial_state") == "expired" else "unconsumed",
                ),
            )
        return digest

    def consume(
        self,
        *,
        authorization_id: str,
        attempt_id: str,
        authorization_digest: str,
        now: int,
        events: SignedEventLog,
    ) -> MintLease:
        secret = secrets.token_bytes(32)
        lease_hash = hashlib.sha256(secret).hexdigest()
        event_id = f"RCE-{uuid.uuid4()}"
        connection = self._connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                "SELECT * FROM authorizations WHERE authorization_id=?",
                (authorization_id,),
            ).fetchone()
            if row is None:
                raise PrototypeError("BLOCKED_TEST_AUTHORIZATION_MISSING")
            if row["attempt_id"] != attempt_id or row["authorization_digest"] != authorization_digest:
                raise PrototypeError("BLOCKED_TEST_AUTHORIZATION_INVALID")
            if row["expires_at"] < now or row["state"] == "expired":
                connection.execute(
                    "UPDATE authorizations SET state='expired' WHERE authorization_id=?",
                    (authorization_id,),
                )
                connection.commit()
                raise PrototypeError("BLOCKED_TEST_AUTHORIZATION_EXPIRED")
            if row["state"] != "unconsumed":
                raise PrototypeError("BLOCKED_TEST_AUTHORIZATION_SPENT")
            changed = connection.execute(
                """UPDATE authorizations
                   SET state='spent', consumption_event_id=?, lease_hash=?
                   WHERE authorization_id=? AND state='unconsumed'""",
                (event_id, lease_hash, authorization_id),
            ).rowcount
            if changed != 1:
                raise PrototypeError("BLOCKED_TEST_AUTHORIZATION_SPENT")
            connection.execute(
                "INSERT INTO registry_events VALUES (?, ?, ?, 'authorization_spent', ?)",
                (event_id, authorization_id, attempt_id, now),
            )
            connection.commit()
        except Exception:
            if connection.in_transaction:
                connection.rollback()
            raise
        finally:
            connection.close()
        events.append(
            "authorization_spent",
            {
                "authorization_id": authorization_id,
                "consumption_event_id": event_id,
                "state": "spent",
            },
        )
        return MintLease(authorization_id, attempt_id, event_id, authorization_digest, secret)

    def claim_mint_lease(self, lease: MintLease) -> None:
        lease_hash = hashlib.sha256(lease.secret).hexdigest()
        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                "SELECT * FROM authorizations WHERE authorization_id=?",
                (lease.authorization_id,),
            ).fetchone()
            require(row is not None, "BLOCKED_TEST_AUTHORIZATION_MISSING")
            require(row["state"] == "spent", "BLOCKED_TEST_AUTHORIZATION_SPENT")
            require(not row["closed"], "BLOCKED_TEST_AUTHORIZATION_SPENT", "attempt closed")
            require(row["attempt_id"] == lease.attempt_id, "BLOCKED_TEST_AUTHORIZATION_INVALID")
            require(row["consumption_event_id"] == lease.consumption_event_id, "BLOCKED_TEST_AUTHORIZATION_INVALID")
            require(row["lease_hash"] == lease_hash, "BLOCKED_TEST_AUTHORIZATION_INVALID", "lease")
            changed = connection.execute(
                "UPDATE authorizations SET mint_claimed=1 WHERE authorization_id=? AND mint_claimed=0",
                (lease.authorization_id,),
            ).rowcount
            require(changed == 1, "BLOCKED_TEST_AUTHORIZATION_SPENT", "mint lease replay")
            connection.commit()

    def close_attempt(self, authorization_id: str) -> None:
        with self._connect() as connection:
            connection.execute(
                "UPDATE authorizations SET closed=1 WHERE authorization_id=?",
                (authorization_id,),
            )

    def register_capability(self, capability_id: str, event_id: str, attempt_id: str) -> None:
        with self._connect() as connection:
            try:
                connection.execute(
                    "INSERT INTO capabilities VALUES (?, ?, ?, 0)",
                    (capability_id, event_id, attempt_id),
                )
            except sqlite3.IntegrityError as exc:
                raise PrototypeError("BLOCKED_RANGE_CAPABILITY_INVALID", "event replay") from exc

    def consume_capability(self, capability_id: str, attempt_id: str) -> None:
        with self._connect() as connection:
            changed = connection.execute(
                "UPDATE capabilities SET consumed=1 WHERE capability_id=? AND attempt_id=? AND consumed=0",
                (capability_id, attempt_id),
            ).rowcount
            require(changed == 1, "BLOCKED_RANGE_CAPABILITY_INVALID", "capability replay")

    def register_delivery(self, delivery_id: str, attempt_id: str) -> None:
        with self._connect() as connection:
            connection.execute(
                "INSERT INTO deliveries VALUES (?, ?, 0)",
                (delivery_id, attempt_id),
            )

    def consume_delivery(self, delivery_id: str, attempt_id: str) -> None:
        with self._connect() as connection:
            changed = connection.execute(
                "UPDATE deliveries SET consumed=1 WHERE delivery_id=? AND attempt_id=? AND consumed=0",
                (delivery_id, attempt_id),
            ).rowcount
            require(changed == 1, "BLOCKED_BOUNDED_READER_REPLAY")

    def state(self, authorization_id: str) -> dict[str, Any]:
        with self._connect() as connection:
            row = connection.execute(
                "SELECT * FROM authorizations WHERE authorization_id=?",
                (authorization_id,),
            ).fetchone()
            if row is None:
                return {"state": "unknown"}
            return dict(row)

    def counts(self, attempt_id: str) -> dict[str, int]:
        with self._connect() as connection:
            return {
                "consumption_events": connection.execute(
                    "SELECT COUNT(*) FROM registry_events WHERE attempt_id=?",
                    (attempt_id,),
                ).fetchone()[0],
                "capabilities": connection.execute(
                    "SELECT COUNT(*) FROM capabilities WHERE attempt_id=?",
                    (attempt_id,),
                ).fetchone()[0],
                "deliveries": connection.execute(
                    "SELECT COUNT(*) FROM deliveries WHERE attempt_id=?",
                    (attempt_id,),
                ).fetchone()[0],
            }

